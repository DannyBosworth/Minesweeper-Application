﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CellChoiceForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CellChoiceForm))
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Cell1 = New System.Windows.Forms.PictureBox()
        Me.Cell2 = New System.Windows.Forms.PictureBox()
        Me.Cell3 = New System.Windows.Forms.PictureBox()
        Me.Cell4 = New System.Windows.Forms.PictureBox()
        Me.Cell5 = New System.Windows.Forms.PictureBox()
        Me.Cell6 = New System.Windows.Forms.PictureBox()
        Me.Cell7 = New System.Windows.Forms.PictureBox()
        Me.Cell8 = New System.Windows.Forms.PictureBox()
        Me.BlankCell = New System.Windows.Forms.PictureBox()
        Me.UnknownCell = New System.Windows.Forms.PictureBox()
        CType(Me.Cell1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cell2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cell3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cell4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cell5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cell6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cell7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Cell8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BlankCell, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UnknownCell, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(32, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(178, 20)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Choose a Cell to Add"
        '
        'Cell1
        '
        Me.Cell1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell1.Image = CType(resources.GetObject("Cell1.Image"), System.Drawing.Image)
        Me.Cell1.Location = New System.Drawing.Point(12, 109)
        Me.Cell1.Name = "Cell1"
        Me.Cell1.Size = New System.Drawing.Size(48, 48)
        Me.Cell1.TabIndex = 14
        Me.Cell1.TabStop = False
        '
        'Cell2
        '
        Me.Cell2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell2.Image = CType(resources.GetObject("Cell2.Image"), System.Drawing.Image)
        Me.Cell2.Location = New System.Drawing.Point(66, 109)
        Me.Cell2.Name = "Cell2"
        Me.Cell2.Size = New System.Drawing.Size(48, 48)
        Me.Cell2.TabIndex = 16
        Me.Cell2.TabStop = False
        '
        'Cell3
        '
        Me.Cell3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell3.Image = Global.OopSweeper.My.Resources.Resources._3CellEnlarged
        Me.Cell3.Location = New System.Drawing.Point(121, 109)
        Me.Cell3.Name = "Cell3"
        Me.Cell3.Size = New System.Drawing.Size(48, 48)
        Me.Cell3.TabIndex = 17
        Me.Cell3.TabStop = False
        '
        'Cell4
        '
        Me.Cell4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell4.Image = Global.OopSweeper.My.Resources.Resources._4CellEnlarged
        Me.Cell4.Location = New System.Drawing.Point(176, 109)
        Me.Cell4.Name = "Cell4"
        Me.Cell4.Size = New System.Drawing.Size(48, 48)
        Me.Cell4.TabIndex = 18
        Me.Cell4.TabStop = False
        '
        'Cell5
        '
        Me.Cell5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell5.Image = Global.OopSweeper.My.Resources.Resources._5CellEnlarged
        Me.Cell5.Location = New System.Drawing.Point(12, 163)
        Me.Cell5.Name = "Cell5"
        Me.Cell5.Size = New System.Drawing.Size(48, 48)
        Me.Cell5.TabIndex = 19
        Me.Cell5.TabStop = False
        '
        'Cell6
        '
        Me.Cell6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell6.Image = Global.OopSweeper.My.Resources.Resources._6CellEnlarged
        Me.Cell6.Location = New System.Drawing.Point(66, 163)
        Me.Cell6.Name = "Cell6"
        Me.Cell6.Size = New System.Drawing.Size(49, 48)
        Me.Cell6.TabIndex = 20
        Me.Cell6.TabStop = False
        '
        'Cell7
        '
        Me.Cell7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell7.Image = Global.OopSweeper.My.Resources.Resources._7CellEnlarged
        Me.Cell7.Location = New System.Drawing.Point(120, 163)
        Me.Cell7.Name = "Cell7"
        Me.Cell7.Size = New System.Drawing.Size(49, 48)
        Me.Cell7.TabIndex = 21
        Me.Cell7.TabStop = False
        '
        'Cell8
        '
        Me.Cell8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Cell8.Image = Global.OopSweeper.My.Resources.Resources._8CellEnlarged
        Me.Cell8.Location = New System.Drawing.Point(175, 163)
        Me.Cell8.Name = "Cell8"
        Me.Cell8.Size = New System.Drawing.Size(49, 48)
        Me.Cell8.TabIndex = 22
        Me.Cell8.TabStop = False
        '
        'BlankCell
        '
        Me.BlankCell.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BlankCell.Image = Global.OopSweeper.My.Resources.Resources.BlankCellEnlarged
        Me.BlankCell.Location = New System.Drawing.Point(41, 55)
        Me.BlankCell.Name = "BlankCell"
        Me.BlankCell.Size = New System.Drawing.Size(49, 48)
        Me.BlankCell.TabIndex = 23
        Me.BlankCell.TabStop = False
        '
        'UnknownCell
        '
        Me.UnknownCell.Cursor = System.Windows.Forms.Cursors.Hand
        Me.UnknownCell.Image = Global.OopSweeper.My.Resources.Resources.UnknownCellEnlarged
        Me.UnknownCell.Location = New System.Drawing.Point(149, 55)
        Me.UnknownCell.Name = "UnknownCell"
        Me.UnknownCell.Size = New System.Drawing.Size(49, 48)
        Me.UnknownCell.TabIndex = 24
        Me.UnknownCell.TabStop = False
        '
        'CellChoiceForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(230, 219)
        Me.Controls.Add(Me.UnknownCell)
        Me.Controls.Add(Me.BlankCell)
        Me.Controls.Add(Me.Cell8)
        Me.Controls.Add(Me.Cell7)
        Me.Controls.Add(Me.Cell6)
        Me.Controls.Add(Me.Cell5)
        Me.Controls.Add(Me.Cell4)
        Me.Controls.Add(Me.Cell3)
        Me.Controls.Add(Me.Cell2)
        Me.Controls.Add(Me.Cell1)
        Me.Controls.Add(Me.Label3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Name = "CellChoiceForm"
        Me.Text = "CellChoiceForm"
        CType(Me.Cell1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cell2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cell3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cell4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cell5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cell6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cell7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Cell8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BlankCell, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UnknownCell, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label3 As Label
    Friend WithEvents Cell1 As PictureBox
    Friend WithEvents Cell2 As PictureBox
    Friend WithEvents Cell3 As PictureBox
    Friend WithEvents Cell4 As PictureBox
    Friend WithEvents Cell5 As PictureBox
    Friend WithEvents Cell6 As PictureBox
    Friend WithEvents Cell7 As PictureBox
    Friend WithEvents Cell8 As PictureBox
    Friend WithEvents BlankCell As PictureBox
    Friend WithEvents UnknownCell As PictureBox
End Class
